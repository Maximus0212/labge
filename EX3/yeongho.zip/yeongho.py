A = ['', '2', '3']
C = []

for i in A:
	A_replace = i.replace('','.')
	C.append(A_replace)
print(C)

#  i want 
# ['.', '2', '3']
